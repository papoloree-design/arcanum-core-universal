
// Optional backup module (disabled by default). Provides structure for future Web3 backups.
window.__arcanum_backup__ = { enabled:false, token:"" };
