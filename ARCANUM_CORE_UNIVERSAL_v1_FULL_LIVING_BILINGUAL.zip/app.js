
(() => {
  const I18N = {
    es: {
      title: "Arcanum Core ∞ <span class='badge'>Universal v1</span>",
      subtitle: "Mainnet‑Beta + Devnet • Auto‑fallback • HUD vivo • Export JSON • Voz opcional",
      netrpc: "Red y RPC",
      state: "Estado",
      watching: "Wallets observadas",
      balances: "Balances",
      sync: "Sincronizar",
      backfill: "Backfill",
      export: "Exportar JSON",
      voice: "Voz: OFF",
      txs: "Transacciones recientes",
      th_time: "Hora",
      th_sig: "Firma",
      th_type: "Tipo",
      th_acct: "Cuenta",
      th_amt: "Monto",
      log: "Log",
      init: "Inicializando…",
      main_ok: (slot)=>`Mainnet OK • slot ${slot}`,
      main_err: "Error Mainnet, usando Devnet",
      dual_on: "Dual‑Safe activo",
      failover: "Failover Devnet",
      backfill_done: "Backfill completado."
    },
    en: {
      title: "Arcanum Core ∞ <span class='badge'>Universal v1</span>",
      subtitle: "Mainnet‑Beta + Devnet • Auto‑fallback • Live HUD • Export JSON • Optional Voice",
      netrpc: "Network & RPC",
      state: "State",
      watching: "Watching wallets",
      balances: "Balances",
      sync: "Sync",
      backfill: "Backfill",
      export: "Export JSON",
      voice: "Voice: OFF",
      txs: "Recent transactions",
      th_time: "Time",
      th_sig: "Signature",
      th_type: "Type",
      th_acct: "Account",
      th_amt: "Amount",
      log: "Log",
      init: "Initializing…",
      main_ok: (slot)=>`Mainnet OK • slot ${slot}`,
      main_err: "Mainnet error, using Devnet",
      dual_on: "Dual‑Safe active",
      failover: "Devnet failover",
      backfill_done: "Backfill completed."
    }
  };

  let lang = (navigator.language||'es').toLowerCase().startsWith('es') ? 'es' : 'en';
  const t = (k, ...a) => (typeof I18N[lang][k] === 'function') ? I18N[lang][k](...a) : I18N[lang][k];

  const $ = (id) => document.getElementById(id);
  const log = (...a) => { const el = $('log'); el.textContent += a.join(' ')+'\n'; el.scrollTop = el.scrollHeight; };
  const speak = (msg) => { if (!window._voiceOn) return; try{ const u=new SpeechSynthesisUtterance(msg); u.lang=(lang==='es'?'es-ES':'en-US'); speechSynthesis.cancel(); speechSynthesis.speak(u);}catch(e){} };

  function applyI18n(){
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      el.innerHTML = t(key);
    });
    $('langBtn').textContent = (lang==='es'?'ES':'EN');
  }

  // Config
  const CFG = {
    networks: {
      mainnet: { name:'Mainnet-Beta', rpc:'https://api.mainnet-beta.solana.com' },
      devnet:  { name:'Devnet',       rpc:'https://api.devnet.solana.com' }
    },
    owner_wallets: [
      'ACWTJLXiXUhfap1ygt1BpLYHscjeaPNEVH6pPNf72MK3',
      'HFNFcP3yJiYtMF2Gzz7RcNiXbLiH4M4TcSYz5TDq26fX'
    ],
    mints: {
      AQR:  '8h4jvgTSSN6xeV6TPMMwCSdmStNdKYUrxhLSB2pBJNZM',
      AUREA:'Evtmyoa2e4fqVByhy1SvSJCvP6kYV8ZSJXdAgZJiZray'
    },
    backfill_limit: 1200,
    pull_interval_ms: 3200
  };

  let connMain=null, connDev=null, tokenProg=null;
  const DBKEY = 'arcanum_universal_v1_full_bilingual';
  const db = {
    push: (tx)=>{
      const data = JSON.parse(localStorage.getItem(DBKEY) || '{"txs":[]}');
      if (!data.txs.find(t=>t.sig===tx.sig)){ data.txs.unshift(tx); data.txs = data.txs.slice(0, 3000); localStorage.setItem(DBKEY, JSON.stringify(data)); }
    },
    all: ()=> JSON.parse(localStorage.getItem(DBKEY) || '{"txs":[]}').txs,
    clear: ()=> localStorage.setItem(DBKEY, JSON.stringify({txs:[]}))
  };

  function draw(){
    const rows = db.all().slice(0,140).map(t=>`
      <tr>
        <td>${new Date(t.time*1000).toLocaleString()}</td>
        <td><code>${t.sig.slice(0,8)}…${t.sig.slice(-6)}</code></td>
        <td>${t.kind}</td>
        <td><code>${t.addr.slice(0,6)}…${t.addr.slice(-4)}</code></td>
        <td>${t.ui ?? '—'}</td>
      </tr>`).join('');
    $('rows').innerHTML = rows;
  }

  async function connectRPC(){
    document.documentElement.lang = (lang==='es'?'es':'en');
    applyI18n();
    $('state').textContent = t('init');

    tokenProg = new solanaWeb3.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
    connMain = new solanaWeb3.Connection(CFG.networks.mainnet.rpc, 'confirmed');
    connDev  = new solanaWeb3.Connection(CFG.networks.devnet.rpc,  'confirmed');
    try {
      const e1 = await connMain.getEpochInfo();
      $('rpc').textContent = t('main_ok', e1.absoluteSlot);
      $('state').textContent = t('dual_on');
    } catch(e){ $('rpc').textContent = t('main_err'); $('state').textContent = t('failover'); }
  }

  async function balances(){
    const owner = new solanaWeb3.PublicKey(CFG.owner_wallets[0]);
    try{
      const lam = await connMain.getBalance(owner);
      $('sol').textContent = (lam/1e9).toFixed(6);
    }catch(e){
      const lam = await connDev.getBalance(owner);
      $('sol').textContent = (lam/1e9).toFixed(6);
    }

    try{
      const parsed = await connMain.getParsedTokenAccountsByOwner(owner, { programId: tokenProg });
      let aqr=0, aur=0;
      parsed.value.forEach(v=>{
        const info = v.account.data.parsed.info;
        const mint = info.mint;
        const ui = info.tokenAmount?.uiAmount || 0;
        if (mint === CFG.mints.AQR) aqr = ui;
        if (mint === CFG.mints.AUREA) aur = ui;
      });
      $('aqr').textContent = aqr;
      $('aur').textContent = aur;
    }catch(e){
      $('aqr').textContent = '—';
      $('aur').textContent = '—';
      log('Token balances not available (mainnet), retrying…');
    }
  }

  async function backfill(){
    db.clear();
    for (const addrStr of CFG.owner_wallets){
      const addr = new solanaWeb3.PublicKey(addrStr);
      let before = undefined, fetched=0;
      while (fetched < CFG.backfill_limit){
        const sigs = await connMain.getSignaturesForAddress(addr, { before, limit: 100 }).catch(()=>[]);
        if (!sigs.length) break;
        for (const s of sigs){
          try{
            const tx = await connMain.getParsedTransaction(s.signature, { maxSupportedTransactionVersion: 0 });
            if (!tx) continue;
            const time = tx.blockTime || Math.floor(Date.now()/1000);
            const pre = tx.meta?.preBalances?.[0] ?? 0;
            const post= tx.meta?.postBalances?.[0] ?? 0;
            const delta = (post-pre)/1e9;
            db.push({ sig:s.signature, time, kind: delta>=0?'IN':'OUT', addr: addrStr, ui: delta });
          }catch(e){}
        }
        fetched += sigs.length;
        before = sigs[sigs.length-1]?.signature;
        document.getElementById('last').textContent = `Backfill ${addrStr}: ${fetched}`;
        draw();
        await new Promise(r=>setTimeout(r,180));
      }
    }
    speak(lang==='es' ? 'Backfill completado.' : 'Backfill completed.');
  }

  async function loop(){
    while(true){
      try{ await balances(); }catch(e){ log('loop error', e.message||e); }
      await new Promise(r=>setTimeout(r, 3200));
    }
  }

  function bind(){
    document.getElementById('btnSync').onclick = balances;
    document.getElementById('btnBackfill').onclick = backfill;
    document.getElementById('btnExport').onclick = () => {
      const blob = new Blob([JSON.stringify(db.all(), null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = 'arcanum_universal_feed.json'; a.click();
      URL.revokeObjectURL(url);
    };
    document.getElementById('btnVoice').onclick = () => {
      window._voiceOn = !window._voiceOn;
      document.getElementById('btnVoice').textContent = (lang==='es'?'Voz: ':'Voice: ') + (window._voiceOn?'ON':'OFF');
      if (window._voiceOn) speak(lang==='es'?'Voz activada.':'Voice on.');
    };
    document.getElementById('langBtn').onclick = () => {
      lang = (lang==='es'?'en':'es');
      applyI18n();
    };
  }

  async function main(){
    applyI18n();
    document.getElementById('watch').textContent = ['ACWTJLXiXUhfap1ygt1BpLYHscjeaPNEVH6pPNf72MK3','HFNFcP3yJiYtMF2Gzz7RcNiXbLiH4M4TcSYz5TDq26fX'].join(', ');
    await connectRPC();
    await balances();
    bind();
    loop();
  }
  window.addEventListener('DOMContentLoaded', main);
})();
